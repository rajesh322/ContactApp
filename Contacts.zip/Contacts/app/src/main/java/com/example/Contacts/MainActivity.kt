package com.example.Contacts

import android.annotation.SuppressLint
import android.graphics.Color
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.View
import android.widget.*
import kotlinx.android.synthetic.main.activity_main.*

import kotlinx.android.synthetic.main.contact_form.*
import kotlinx.android.synthetic.main.contacts_table.*


import kotlinx.android.synthetic.main.login.*

import kotlinx.android.synthetic.main.user_registration.*
import kotlinx.android.synthetic.main.user_registration.email
import kotlinx.android.synthetic.main.user_registration.name
import kotlinx.android.synthetic.main.user_registration.registraion_layout
import android.view.Gravity

import android.graphics.Typeface
import android.util.Log

import android.util.TypedValue

import android.widget.EditText




class MainActivity : AppCompatActivity() {
    lateinit var handler: database_helper
    internal lateinit var sp:Spinner
    internal lateinit var sp1:Spinner
    internal  lateinit var sp2:Spinner
    internal lateinit var sp3:Spinner
    @SuppressLint("WrongViewCast")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        handler=database_helper(this)
//        sp=findViewById(R.id.dropdown) as Spinner
//        val dd=arrayOf("Neurologist","Dentist","Pediatrician","Cardiologist","ENT","Gynaecologist")
//        val adapter1=ArrayAdapter(this,android.R.layout.simple_list_item_1,dd)
//        sp.adapter=adapter1
        homepage()

        registration.setOnClickListener{
            showRegisterationform()
        }
        login.setOnClickListener{
            showLoginform()
        }
        save.setOnClickListener{
           var a= handler.insertdata(name.text.toString(),email.text.toString(),passwordregister.text.toString())
            if(a=="registered")
                homepage()
            else {
                Toast.makeText(this, a, Toast.LENGTH_SHORT).show()

            }

        }
        loginuser.setOnClickListener {

            if(handler.insertlogindata(login_email.text.toString(),login_password.text.toString())) {
                contactPage()
                Toast.makeText(this, "login Successful", Toast.LENGTH_SHORT).show()
                addContact.setOnClickListener {
                    var contact_name = contactName.text.toString()
                    var contact_email = contactEmail.text.toString()
                    var phone_no = phoneNo.text.toString()
                    var contactResult =
                        handler.insertContactData(contact_name, contact_email, phone_no)
                    if (contactResult == "Contact added Successfully") {
                        contactPage()
                        Toast.makeText(this, contactResult, Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, contactResult, Toast.LENGTH_SHORT).show()
                    }


                }
                viewContact.setOnClickListener{
                    viewContacts()

                    var table:TableLayout=findViewById<TableLayout>(R.id.contact_table_layout)
//                    var count=table.childCount
                    table.removeAllViews()
//
                    var layoutParams = TableRow.LayoutParams(
                        TableRow.LayoutParams.WRAP_CONTENT)



                    var row:TableRow=TableRow(this)
                    var tv1=TextView(this)
                    tv1.text="Name"

                    row.addView(tv1,layoutParams);
                    var tv2=TextView(this)
                    tv2.text="Contact No"
                    tv2.left=120
                    row.addView(tv2,layoutParams);

                    var tv3=TextView(this)
                    tv3.text="Email"
                    row.addView(tv3,layoutParams);
                    table.addView(row)
                    var contacts=handler.getAllContacts()
                    Toast.makeText(this, "hello", Toast.LENGTH_SHORT).show()
                    Log.d("msg", contacts.toString())
                    for(i in contacts)
                    {
                        var details=i.split(",")
                        var row:TableRow=TableRow(this)
                        var tv1=TextView(this)
                        tv1.text=details[0]
                        row.addView(tv1,layoutParams);
                        var tv2=TextView(this)
                        tv2.text=details[1]
                        row.addView(tv2,layoutParams);
                        var tv3=TextView(this)

                        tv3.text=details[2]
                        row.addView(tv3,layoutParams);
                        table.addView(row)


                    }
                    var button=Button(this)
                    table.addView(button)
                    button.text="Add Contact"
                    button.setOnClickListener{
                        contactPage()
                    }

                }

            }
            else
            {
                Toast.makeText(this,"username or password is incorrect ",Toast.LENGTH_SHORT).show()
                showLoginform()
            }
        }
    }
    private fun showRegisterationform()
    {
    registraion_layout.visibility=View.VISIBLE
        login_layout.visibility=View.GONE
        home.visibility=View.GONE
        contact_layout.visibility=View.GONE



    }
    private fun contactPage()
    {
        registraion_layout.visibility=View.GONE
        login_layout.visibility=View.GONE
        contact_layout.visibility=View.VISIBLE
        home.visibility=View.GONE
        contact_table_layout.visibility=View.GONE


    }
    private  fun showLoginform()
    {
        registraion_layout.visibility=View.GONE
        login_layout.visibility=View.VISIBLE
        home.visibility=View.GONE
        contact_layout.visibility=View.GONE

    }
    private  fun homepage()
    {
        registraion_layout.visibility=View.GONE
        login_layout.visibility=View.GONE
        home.visibility=View.VISIBLE

        contact_layout.visibility=View.GONE


    }






    private fun viewContacts(){
        registraion_layout.visibility=View.GONE
        login_layout.visibility=View.GONE
//        home.visibility=View.VISIBLE
        home.visibility=View.GONE
        contact_layout.visibility=View.GONE
        contact_table_layout.visibility=View.VISIBLE
    }
}
