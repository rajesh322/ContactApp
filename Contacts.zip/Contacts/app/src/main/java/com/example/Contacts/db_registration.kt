package com.example.Contacts

import android.content.ContentValues
import android.content.Context
import android.database.sqlite.SQLiteDatabase
import android.database.sqlite.SQLiteOpenHelper

class database_helper(context:Context):SQLiteOpenHelper(context, databasename,factory, version) {
    companion object {
        internal val databasename = "userdatabase"
        internal val factory = null
        internal val version = 20
    }

    override fun onCreate(p: SQLiteDatabase?) {

        p?.execSQL(
            "create table contacts(id integer primary key autoincrement,name varchar(30),phoneNo varchar(10),email varchar(30))"
        )
        p?.execSQL(
            "create table newuser(id integer primary key autoincrement," + "name varchar(50) unique,email varchar(150) unique,password " +
                    "varchar(30))"
        )



    }


    override fun onUpgrade(db: SQLiteDatabase?, oldVersion: Int, newVersion: Int) {
        db?.execSQL("drop table if exists newuser")
        db?.execSQL("drop table if exists contacts")
        onCreate(db)
        //To change body of created functions use File | Settings | File Templates.
    }

    fun insertdata(name: String, email: String, password: String):String {
        val db: SQLiteDatabase = writableDatabase
        val values: ContentValues = ContentValues()
        val query2="select *from newuser where name='$name' and email='$email'"
        val e=db.rawQuery(query2,null)
        val query="select *from newuser where name='$name'"
        val c=db.rawQuery(query,null)
        val query1="select *from newuser where email='$email'"
        val d=db.rawQuery(query1,null)
        var email_pattern="[a-zA-Z0-9._-]+@[a-z]+\\.+[a-z]+".toRegex()
        if(!(email.matches(email_pattern)))
            return "please enter a valid email_id"
        else if(c.count>0)
            return "username already exists"

        else if(d.count>0)
            return "email already exists"
        else if(e.count>0)
            return "username and email already exists"
        else {
            values.put("name", name)
            values.put("email", email)
            values.put("password", password)
            db.insert("newuser", null, values)
            db.close()
            return "registered"
        }


    }

    fun insertlogindata(email: String, password: String): Boolean {
        val db: SQLiteDatabase = writableDatabase
        val query = "select *from newuser where email='$email' and password='$password'"
        val c = db.rawQuery(query, null)
        if (c.count <= 0) {
            c.close()
            return false
        } else {
            c.close()
            return true
        }


    }
    fun insertContactData(name:String,email: String,phoneNo:String):String
    {
        val db: SQLiteDatabase = writableDatabase
        val values: ContentValues = ContentValues()
        val query="select *from contacts where name='$name'"
        val c=db.rawQuery(query,null)
        val query1="select *from contacts where phoneNo='$phoneNo'"
        val d=db.rawQuery(query1,null)
         if(c.count>0)
            return "username already exists"
        else if(d.count>0)
            return "contactNo already exists"
        else {
            values.put("name", name)
            values.put("email", email)
            values.put("phoneNo", phoneNo)
            db.insert("contacts", null, values)
            db.close()
            return "Contact added Successfully"
        }

    }
    fun getAllContacts():List<String>
    {
        val db: SQLiteDatabase = writableDatabase
        val query = "select * from contacts "
        val c = db.rawQuery(query, null)
        val contacts = mutableListOf<String>()
        if (c.count > 0) {
            while (c.moveToNext()) {
                var name = c.getString(c.getColumnIndex("name"))
                var phoneNo = c.getString(c.getColumnIndex(("phoneNo")))
                var email = c.getString(c.getColumnIndex(("email")))

                contacts.add(name +","+phoneNo+","+email)


            }
        }
        return contacts
    }

}